<?php 
	function writeName2($firstname){
		echo $firstname." Sharma";

	}

	echo "My name is ";
	writeName2("Jai");

	echo "<br>";


	echo "My brother's name is ";
	writeName2("Ram");

	

?>