<?php
function writeName()
{
	echo "Ramachandra";
}
echo "My name is ";
writeName();
?>
