<?php
$x=array("One","Two","Three");
foreach($x as $y)
{
	echo("$y<br>");
}
?>