<?php
$num1=10;
$num2=2;
echo "Adition: ".($num1 + $num2)."<br/>";
echo "Subtraction: ".($num1 - $num2)."<br/>";
echo "Multiplication: ".($num1 * $num2)."<br/>";
echo "Division: ".($num1 / $num2);
?>
