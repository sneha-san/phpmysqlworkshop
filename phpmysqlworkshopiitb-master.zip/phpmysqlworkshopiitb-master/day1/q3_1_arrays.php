<?php
$week=array(1 =>'Sunday' ,2=>'Monday',3=>'Tuesday',4=>'Wednesday',5=>'Thursday',6=>'Friday',7=>'Saturday' );
echo "$week[1]<br/>";
echo "$week[2]<br/>";
echo "$week[3]<br/>";
echo "$week[4]<br/>";
echo "$week[5]<br/>";
echo "$week[6]<br/>";
echo "$week[7]<br/>";
?>
