<?php
$num1=10;
$num2=2;
if ($num1>$num2) {
	echo "$num1 is greater than $num2";
}
elseif ($num1<$num2) {
	echo "$num1 is lesser than $num2";
}
else
echo "The numbers are equal";

?>