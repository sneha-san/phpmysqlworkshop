<?php
$num=44;
if ($num%2==0) {
	echo "The number $num is an even number.";
}
else{
	echo "The number $num is an odd number.";
}
?>